// Cầu nối app <-> trang.
//  1) Ẩn/hiện bảng điều khiển gốc của userscript (menu đã chuyển sang app).
//  2) Bản thu nhỏ của trang: snap() trả ảnh PNG (data URL) để menu của app hiển thị.
// window.__TT_HIDE và window.__TT_MINI do MainActivity đặt ngay trước file này.
(function () {
  if (window.__TT) return;

  // ---------- 1) ẩn bảng điều khiển gốc ----------
  var st = null;
  function apply() {
    var root = document.head || document.documentElement;
    if (!root) return;
    if (window.__TT_HIDE && !st) {
      st = document.createElement('style');
      st.textContent = '[data-psbot-dock]{display:none!important}';
      root.appendChild(st);
    } else if (!window.__TT_HIDE && st) {
      st.remove();
      st = null;
    }
  }

  // ---------- 2) bản thu nhỏ của trang (hiện trong menu của app) ----------
  // Lấy hàm vẽ gốc NGAY bây giờ (bridge chạy trước userscript): lớp lite/bot của userscript sẽ bọc
  // CanvasRenderingContext2D.prototype.drawImage sau đó, ta không muốn bản thu nhỏ bị chúng lọc hay ghi nhận.
  var nativeDraw = CanvasRenderingContext2D.prototype.drawImage;
  var DEF = { style: 'full', mode: 'page' };
  var cfg = {};
  var cv = null, g = null, items = [], itemsAt = -1e9;
  var PW = 420;   // chiều rộng ảnh xem trước (px)

  function mergeCfg(o) {
    for (var k in DEF) cfg[k] = (o && o[k] !== undefined) ? o[k] : (cfg[k] !== undefined ? cfg[k] : DEF[k]);
  }

  var SKIP = /^(SCRIPT|STYLE|LINK|META|HEAD|TITLE|NOSCRIPT|BR|TEMPLATE|OPTION)$/;

  // Quét DOM thành danh sách hình đơn giản theo thứ tự tài liệu. Chậm hơn nên chỉ làm vài lần/giây.
  function scan() {
    var out = [], n = 0, VW = innerWidth, VH = innerHeight;
    var tw = document.createTreeWalker(document.body, NodeFilter.SHOW_ELEMENT);
    var el;
    while ((el = tw.nextNode()) && n < 700) {
      if (SKIP.test(el.tagName) || el.closest('[data-psbot-ui],[data-tt-mini]')) continue;
      var r = el.getBoundingClientRect();
      if (r.width < 2 || r.height < 2 || r.right < 0 || r.bottom < 0 || r.left > VW || r.top > VH) continue;
      var cs = getComputedStyle(el);
      if (cs.display === 'none' || cs.visibility === 'hidden' || cs.opacity === '0') continue;
      var tag = el.tagName, it = null;
      if (tag === 'CANVAS') {
        out.push({ t: 'cv', el: el, r: r }); n++; continue;
      }
      var bg = cs.backgroundColor, hasBg = bg && bg !== 'transparent' && !/rgba\(.*,\s*0\)$/.test(bg);
      var bw = parseFloat(cs.borderTopWidth) || 0, hasBd = bw > 0 && cs.borderTopStyle !== 'none';
      var rad = parseFloat(cs.borderTopLeftRadius) || 0;
      if (tag === 'IMG' || tag === 'VIDEO' || tag === 'SVG' || tag === 'svg') {
        out.push({ t: 'media', r: r, rad: rad }); n++;
      } else if (hasBg || hasBd || tag === 'INPUT' || tag === 'SELECT' || tag === 'TEXTAREA' || tag === 'BUTTON') {
        out.push({ t: 'box', r: r, rad: rad, bg: hasBg ? bg : null, bd: hasBd ? cs.borderTopColor : (tag === 'INPUT' || tag === 'SELECT' || tag === 'TEXTAREA' ? '#889' : null) });
        n++;
      }
      // chữ: node text trực tiếp của phần tử này -> vẽ thành các vạch
      var txt = '';
      for (var c = el.firstChild; c; c = c.nextSibling) if (c.nodeType === 3) txt += c.nodeValue;
      txt = txt.replace(/\s+/g, ' ').trim();
      if (!txt && (tag === 'INPUT' || tag === 'TEXTAREA')) txt = (el.value || el.placeholder || '').trim();
      if (txt) {
        var fs = parseFloat(cs.fontSize) || 12, lh = parseFloat(cs.lineHeight) || fs * 1.25;
        var lines = Math.max(1, Math.min(6, Math.round(r.height / lh)));
        var wpx = Math.min(r.width, txt.length * fs * 0.52 / lines + fs);
        out.push({ t: 'txt', x: r.left + (tag === 'BUTTON' || cs.textAlign === 'center' ? (r.width - wpx) / 2 : 0), y: r.top, w: wpx, lines: lines, lh: lh, fs: fs, col: cs.color });
        n++;
      }
    }
    return out;
  }

  function rr(ctx, x, y, w, h, rad) {
    if (rad > 1 && ctx.roundRect) { ctx.beginPath(); ctx.roundRect(x, y, w, h, Math.min(rad, w / 2, h / 2)); return true; }
    return false;
  }

  function gameCanvas() {
    return document.getElementById('game') || document.querySelector('canvas.ps-canvas') ||
      document.querySelector('canvas:not([data-psbot-ui])');
  }

  function drawCanvas(c, r, k) {
    try { nativeDraw.call(g, c, r.left * k, r.top * k, r.width * k, r.height * k); } catch (e) {}
  }

  function posterize() {
    try {
      var im = g.getImageData(0, 0, cv.width, cv.height), d = im.data;
      for (var i = 0; i < d.length; i += 4) {
        d[i] = (d[i] + 32) >> 6 << 6; d[i + 1] = (d[i + 1] + 32) >> 6 << 6; d[i + 2] = (d[i + 2] + 32) >> 6 << 6;
      }
      g.putImageData(im, 0, 0);
    } catch (e) {}
  }

  function render() {
    if (!cv) { cv = document.createElement('canvas'); cv.setAttribute('data-psbot-ui', ''); g = cv.getContext('2d'); }
    var W = PW, H = Math.max(30, Math.round(PW * innerHeight / Math.max(1, innerWidth)));
    if (cv.width !== W || cv.height !== H) { cv.width = W; cv.height = H; }
    var k = W / Math.max(1, innerWidth);
    g.globalAlpha = 1;
    g.fillStyle = (getComputedStyle(document.body).backgroundColor || '#000');
    if (g.fillStyle === 'rgba(0, 0, 0, 0)') g.fillStyle = '#0b0f14';
    g.fillRect(0, 0, W, H);
    g.imageSmoothingEnabled = cfg.style !== 'simple';

    if (cfg.mode === 'canvas') {
      var gc = gameCanvas();
      if (gc) {
        var r0 = gc.getBoundingClientRect();
        drawCanvas(gc, r0, k);
      }
    } else {
      var now = performance.now();
      if (now - itemsAt > 450) { items = scan(); itemsAt = now; }
      for (var i = 0; i < items.length; i++) {
        var it = items[i];
        if (it.t === 'cv') { drawCanvas(it.el, it.el.getBoundingClientRect(), k); continue; }
        if (it.t === 'txt') {
          g.fillStyle = it.col; g.globalAlpha = 0.85;
          var bh = Math.max(1, it.fs * 0.55 * k);
          for (var l = 0; l < it.lines; l++) {
            var ww = l === it.lines - 1 && it.lines > 1 ? it.w * 0.6 : it.w;
            g.fillRect(it.x * k, (it.y + l * it.lh + (it.lh - it.fs * 0.55) / 2) * k, Math.max(1, ww * k), bh);
          }
          g.globalAlpha = 1; continue;
        }
        var x = it.r.left * k, y = it.r.top * k, w = it.r.width * k, h = it.r.height * k;
        if (it.t === 'media') {
          g.fillStyle = '#5a6577'; g.strokeStyle = '#9aa7ba';
          if (!rr(g, x, y, w, h, it.rad * k)) { g.beginPath(); g.rect(x, y, w, h); }
          g.fill(); g.stroke(); continue;
        }
        if (it.bg) { g.fillStyle = it.bg; if (!rr(g, x, y, w, h, it.rad * k)) { g.beginPath(); g.rect(x, y, w, h); } g.fill(); }
        if (it.bd) { g.strokeStyle = it.bd; if (!rr(g, x, y, w, h, it.rad * k)) { g.beginPath(); g.rect(x, y, w, h); } g.stroke(); }
      }
    }
    if (cfg.style === 'simple') posterize();
  }

  function snap() {
    if (!document.body) return null;
    render();
    return cv.toDataURL('image/png');
  }

  mergeCfg(window.__TT_MINI);

  window.__TT = {
    hide: function (b) { window.__TT_HIDE = !!b; apply(); },
    mini: {
      set: function (o) { mergeCfg(o); itemsAt = -1e9; },
      get: function () { return JSON.parse(JSON.stringify(cfg)); },
      snap: snap
    }
  };
  apply();
  document.addEventListener('DOMContentLoaded', apply);
})();
